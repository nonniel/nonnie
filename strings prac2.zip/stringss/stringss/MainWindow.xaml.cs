﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib;

namespace stringss
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int length(string s)
        {
            int totallength = 0;
            foreach (char p in s)
            {
                totallength = totallength + 1;
            }
            return totallength;
        }
        bool contains(string s, string subs)
        {
            foreach (char c in s)
            {
                foreach (char p in subs)
                {
                    if (c == p)
                    {
                        return true;
                    }
                }

            }
            return false;
        }
        int indexOf(string s, string subs)
        {
            int index = -1;
            foreach (char c in s)
            {
                index = index + 1;
                foreach (char p in subs)
                {
                    if (c == p)
                    {
                        return index;
                    }
                }

            }
            return -1;
        }
        string insertSubString(string s, string x, int pos)
        {
            string r = "";
            int p = 0;
            foreach(char c in s)
            {
                if (p == pos)
                {
                    r = r + x+c;
                }
                else
                    r = r + c;
                p++;
            }
            return r;
        }
        string replaceSubString(string s, string old, string nw)
        {
            string neww = "";
            int j = 0;
            if (length(old) == 1)
            {
                for (int i = 0; i < length(s); i++)
                {
                    if (s[i] != old[j])
                    {
                        neww = neww + s[i];
                    }
                    else
                    {
                        neww = neww + nw;
                    }
                }
            }
            if (length(old) > 1)
            {
                for (int i = 0; i < length(s); i++)
                {
                    if (s[i] != old[j])
                    {
                        neww = neww + s[i];
                    }
                    else
                    {
                        neww = neww + nw;
                        j++;
                    }
                }
            }

            return neww;
        }
        string deleteSubString(string s, string subs)
        {
            string neww = "";
            int j = 0;
            if (length(subs) == 1)
            {
                for (int i = 0; i < length(s); i++)
                {
                    if (s[i] != subs[j])
                    {
                        neww = neww + s[i];
                    }

                }
            }
            if (length(subs) > 1)
            {
                for (int i = 0; i < length(s); i++)
                {
                    if (s[i] != subs[j])
                    {
                        neww = neww + s[i];
                    }
                    else
                    {
                        j++;
                    }
                }
            }

            return neww;
        }
        List<string> split(string s, char c)
        {
            List<string> o = new List<string> { };
            
            string a = "";
            for (int i = 0; i < length(s); i++)
            {
               
                if (s[i] != c)
                {
                    a = a + s[i];
                    
                   
                    continue;
                }
                else
                {
                    o.Add(a);
                    a = "";
                    continue;
                }
                

            }
            o.Add(a);
            return o;
        }
        int stringCompare(string s1, string s2)
        {
            int i = 0;
            if (s1[i] < s2[i] && s1[i] != s2[i])
            {

                return -1;
            }
            if (s1[i] == s2[i])
            {
                i++;
                if (s1[i] < s2[i] && s1[i] != s2[i])
                {

                    return -1;
                }
            }
            if (s1[i] > s2[i] && s1[i] != s2[i])
            {

                return 1;
            }
            if (s1[i] == s2[i])
            {
                i++;
                if (s1[i] > s2[i] && s1[i] != s2[i])
                {

                    return 1;
                }
            }
            return 0;
        }
        string toUpper(string s)
        {
            string idk = "";
            string a = "";
            for (int ii = 0; ii < length(s); ii++)
            {
                if (s[ii] == 'a' || s[ii] == 'A')
                {
                    a = "A";
                }
                if (s[ii] == 'b' || s[ii] == 'B')
                {
                    a = "B";
                }
                if (s[ii] == 'c' || s[ii] == 'C')
                {
                    a = "C";
                }
                if (s[ii] == 'd' || s[ii] == 'D')
                {
                    a = "D";
                }
                if (s[ii] == 'e' || s[ii] == 'E')
                {
                    a = "E";
                }
                if (s[ii] == 'f' || s[ii] == 'F')
                {
                    a = "F";
                }
                if (s[ii] == 'g' || s[ii] == 'G')
                {
                    a = "G";
                }
                if (s[ii] == 'h' || s[ii] == 'H')
                {
                    a = "H";
                }
                if (s[ii] == 'i' || s[ii] == 'I')
                {
                    a = "I";
                }
                if (s[ii] == 'j' || s[ii] == 'J')
                {
                    a = "J";
                }
                if (s[ii] == 'k' || s[ii] == 'K')
                {
                    a = "K";
                }
                if (s[ii] == 'l' || s[ii] == 'L')
                {
                    a = "L";
                }
                if (s[ii] == 'm' || s[ii] == 'M')
                {
                    a = "M";
                }
                if (s[ii] == 'n' || s[ii] == 'N')
                {
                    a = "N";
                }
                if (s[ii] == 'o' || s[ii] == 'O')
                {
                    a = "O";
                }
                if (s[ii] == 'p' || s[ii] == 'P')
                {
                    a = "P";
                }
                if (s[ii] == 'q' || s[ii] == 'Q')
                {
                    a = "Q";
                }
                if (s[ii] == 'r' || s[ii] == 'R')
                {
                    a = "R";
                }
                if (s[ii] == 's' || s[ii] == 'S')
                {
                    a = "S";
                }
                if (s[ii] == 't' || s[ii] == 'T')
                {
                    a = "T";
                }
                if (s[ii] == 'u' || s[ii] == 'U')
                {
                    a = "U";
                }
                if (s[ii] == 'w' || s[ii] == 'W')
                {
                    a = "W";
                }
                if (s[ii] == 'x' || s[ii] == 'X')
                {
                    a = "X";
                }
                if (s[ii] == 'v' || s[ii] == 'V')
                {
                    a = "V";
                }
                if (s[ii] == 'y' || s[ii] == 'Y')
                {
                    a = "Y";
                }
                if (s[ii] == 'z' || s[ii] == 'Z')
                {
                    a = "Z";
                }
                idk = idk + a;
            }
            return idk;
        }
    
        string toLower(string s)
        {
            string idk = "";
            string a = "";
            for (int ii = 0; ii < length(s); ii++)
            {
                if (s[ii] == 'a' || s[ii] == 'A')
                {
                    a = "a";
                }
                if (s[ii] == 'b' || s[ii] == 'B')
                {
                    a = "b";
                }
                if (s[ii] == 'c' || s[ii] == 'C')
                {
                    a = "c";
                }
                if (s[ii] == 'd' || s[ii] == 'D')
                {
                    a = "d";
                }
                if (s[ii] == 'e' || s[ii] == 'E')
                {
                    a = "e";
                }
                if (s[ii] == 'f' || s[ii] == 'F')
                {
                    a = "f";
                }
                if (s[ii] == 'g' || s[ii] == 'G')
                {
                    a = "g";
                }
                if (s[ii] == 'h' || s[ii] == 'H')
                {
                    a = "h";
                }
                if (s[ii] == 'i' || s[ii] == 'I')
                {
                    a = "i";
                }
                if (s[ii] == 'j' || s[ii] == 'J')
                {
                    a = "j";
                }
                if (s[ii] == 'k' || s[ii] == 'K')
                {
                    a = "k";
                }
                if (s[ii] == 'l' || s[ii] == 'L')
                {
                    a = "l";
                }
                if (s[ii] == 'm' || s[ii] == 'M')
                {
                    a = "m";
                }
                if (s[ii] == 'n' || s[ii] == 'N')
                {
                    a = "n";
                }
                if (s[ii] == 'o' || s[ii] == 'O')
                {
                    a = "o";
                }
                if (s[ii] == 'p' || s[ii] == 'P')
                {
                    a = "p";
                }
                if (s[ii] == 'q' || s[ii] == 'Q')
                {
                    a = "q";
                }
                if (s[ii] == 'r' || s[ii] == 'R')
                {
                    a = "r";
                }
                if (s[ii] == 's' || s[ii] == 'S')
                {
                    a = "s";
                }
                if (s[ii] == 't' || s[ii] == 'T')
                {
                    a = "t";
                }
                if (s[ii] == 'u' || s[ii] == 'U')
                {
                    a = "u";
                }
                if (s[ii] == 'w' || s[ii] == 'W')
                {
                    a = "w";
                }
                if (s[ii] == 'x' || s[ii] == 'X')
                {
                    a = "x";
                }
                if (s[ii] == 'v' || s[ii] == 'V')
                {
                    a = "v";
                }
                if (s[ii] == 'y' || s[ii] == 'Y')
                {
                    a = "y";
                }
                if (s[ii] == 'z' || s[ii] == 'Z')
                {
                    a = "z";
                }
                idk = idk + a;
            }
            return idk;
        }
      

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(length("frog"), 4);
            Tester.TestEq(length("xxx"), 3);
            Tester.TestEq(length("nonny"), 5);
            Tester.TestEq(length("i love me"), 9);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(contains("frog","rog"), true);
            Tester.TestEq(contains("xxyxx", "y"), true);
            Tester.TestEq(contains("frog", "qz"), false);
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(indexOf("frog", "rog"), 1);
            Tester.TestEq(indexOf("xxyxx", "y"), 2);
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(deleteSubString("xxyxx", "y"), "xxxx");
            Tester.TestEq(deleteSubString("frog", "rog"), "f");
            Tester.TestEq(deleteSubString("fock", "ck"), "fo");

        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(stringCompare("xxxx", "xxxx"),0 );
            Tester.TestEq(stringCompare("apple", "frog"),-1);
            Tester.TestEq(stringCompare("apple", "king"), -1);
            Tester.TestEq(stringCompare("zod", "frog"), 1);
            Tester.TestEq(stringCompare("photosythesis", "mathematics"), 1);
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(replaceSubString("xxyxx", "y","ooo"), "xxoooxx");
            Tester.TestEq(replaceSubString("frog", "rog","ooo"), "fooooooooo");
            Tester.TestEq(replaceSubString("fock", "ck","eee"), "foeeeeee");
        }

        private void button7_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(toLower("Hello"), "hello");
            Tester.TestEq(toLower("PINK"), "pink");
            Tester.TestEq(toLower("NiCOLE"), "nicole");
            Tester.TestEq(toLower("LoVe"), "love");
        }

        private void button8_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(toUpper("Hello"), "HELLO");
            Tester.TestEq(toUpper("PINK"), "PINK");
            Tester.TestEq(toUpper("NiCOLE"), "NICOLE");
            Tester.TestEq(toUpper("LoVe"), "LOVE");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(split("x xxx", ' '),new List<string> { "x", "xxx"});
            Tester.TestEq(split("x xxx fo o k lll", ' '), new List<string> { "x", "xxx","fo","o","k","lll" });
            Tester.TestEq(split("x xxx m c pol fock", ' '), new List<string> { "x", "xxx","m","c","pol","fock" });
        }

        private void button9_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(insertSubString("xxxx", "y", 2), "xxyxx");
            Tester.TestEq(insertSubString("xxx", "y", 2), "xxyx");
            Tester.TestEq(insertSubString("xxx", "y", 1), "xyxx");
            Tester.TestEq(insertSubString("nonny", "elvis", 2), "noelvisnny");
        }
    }
}
