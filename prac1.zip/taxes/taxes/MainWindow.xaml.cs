﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace taxes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

            double num = Convert.ToDouble(a.Text);
            double answer = 0;
            if (num >= 0 && num <= 188000)
            {
                answer = num * 0.18;
            }
            if (num > 188000 && num <= 293600)
            {
                answer = (num - 188000) * 0.26 + 33840;
            }
            if (num > 293600 && num <= 406400)
            {
                answer = (num - 406400) * 0.31 + 61296;
            }
            if (num > 406400 && num <= 550100)
            {
                answer = (num - 550100) * 0.36 + 96264;
            }
            if (num > 550100 && num <= 701300)
            {
                answer = (num - 701300) * 0.39 + 147996;
            }
            if (num > 701300)
            {
                answer = (num - 701300) * 0.41 + 206964;
            }
            string p = Convert.ToString(answer);
            b.Text = p;
        }
    }
    }

